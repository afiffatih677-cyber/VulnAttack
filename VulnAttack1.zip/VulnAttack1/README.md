# vulnAttack v3.0 – Full Exploit Engine

**Author:** Apipboys  
**Version:** 3.0 FINAL (FIXED)

## Fitur
- 14 jenis serangan
- 5000+ payload per kategori
- Multi-Dork (Google, Bing, DuckDuckGo)
- Deep Analysis
- Deploy Webshell
- Deface
- Multi-thread
- Cross-platform

## Cara Install

### Termux
```bash
pkg update && pkg upgrade -y
pkg install python git -y
git clone https://github.com/Apipboys/vulnAttack
cd vulnAttack
pip install -r requirements.txt
python generate_payloads.py
```

### Kali Linux
```bash
sudo apt update && sudo apt upgrade -y
sudo apt install python3 python3-pip git -y
git clone https://github.com/Apipboys/vulnAttack
cd vulnAttack
pip3 install -r requirements.txt
python3 generate_payloads.py
```

### Windows
```cmd
pip install requests colorama
git clone https://github.com/Apipboys/vulnAttack
cd vulnAttack
python generate_payloads.py
```

### macOS
```bash
brew install python git
pip3 install -r requirements.txt
python3 generate_payloads.py
```

### Docker
```bash
docker build -t vulnattack .
docker run -it --rm vulnattack http://target.com
```

## Cara Pakai

```bash
# Scan single target
python vulnAttack.py http://target.com

# Multi-Dorking
python vulnAttack.py --dork "inurl:index.php?id="

# Scan multiple targets
python vulnAttack.py --list targets.txt --threads 20
```

## Menu Interaktif
1. Deploy Webshell
2. Deface
3. Generate POC
4. Deep Analysis
5. Exit